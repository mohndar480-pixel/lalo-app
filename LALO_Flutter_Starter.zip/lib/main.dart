import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

const navy = Color(0xFF111827);
const blue = Color(0xFF4F8CFF);
final notifications = FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tzdata.initializeTimeZones();
  // Initial launch default for this Saudi-focused first prototype.
  // Before publishing internationally, resolve the device's actual timezone.
  tz.setLocalLocation(tz.getLocation('Asia/Riyadh'));
  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  const ios = DarwinInitializationSettings(
    requestAlertPermission: true,
    requestBadgePermission: true,
    requestSoundPermission: true,
  );
  await notifications.initialize(
    const InitializationSettings(android: android, iOS: ios),
  );
  runApp(const LaloApp());
}

class LaloApp extends StatelessWidget {
  const LaloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LALO',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.dark),
        scaffoldBackgroundColor: navy,
        cardTheme: CardThemeData(
          color: const Color(0xFF1D293B),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF1D293B),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class LaloTask {
  LaloTask({
    required this.id, required this.title, required this.kind,
    required this.priority, required this.dateText, required this.timeText,
    required this.dateType, required this.note, this.notificationId,
  });
  final String id, title, kind, priority, dateText, timeText, dateType, note;
  final int? notificationId;

  Map<String, dynamic> toJson() => {
    'id': id, 'title': title, 'kind': kind, 'priority': priority,
    'dateText': dateText, 'timeText': timeText, 'dateType': dateType,
    'note': note, 'notificationId': notificationId,
  };

  factory LaloTask.fromJson(Map<String, dynamic> j) => LaloTask(
    id: j['id'], title: j['title'], kind: j['kind'], priority: j['priority'],
    dateText: j['dateText'], timeText: j['timeText'], dateType: j['dateType'],
    note: j['note'] ?? '', notificationId: j['notificationId'],
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  List<LaloTask> tasks = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('lalo.tasks');
    if (raw != null) {
      try {
        tasks = (jsonDecode(raw) as List).map((e) => LaloTask.fromJson(e)).toList();
      } catch (_) {}
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('lalo.tasks', jsonEncode(tasks.map((e) => e.toJson()).toList()));
  }

  Future<void> _addTask() async {
    final result = await showModalBottomSheet<LaloTask>(
      context: context, isScrollControlled: true, backgroundColor: const Color(0xFF111827),
      builder: (_) => const AddTaskSheet(),
    );
    if (result == null) return;
    setState(() => tasks.insert(0, result));
    await _save();
    if (result.notificationId != null) {
      // Scheduling was attempted in the form. The task is still saved if OS permission is denied.
    }
  }

  Future<void> _delete(LaloTask task) async {
    if (task.notificationId != null) await notifications.cancel(task.notificationId!);
    setState(() => tasks.removeWhere((e) => e.id == task.id));
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dashboard(),
      _taskList('عام', tasks.where((t) => t.kind == 'مهمة').toList()),
      _taskList('أحداث الألعاب', tasks.where((t) => t.kind == 'لعبة').toList()),
      _about(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('LALO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
        actions: [IconButton(onPressed: _addTask, icon: const Icon(Icons.add_alarm_rounded), tooltip: 'إضافة تنبيه')],
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : pages[tab],
      floatingActionButton: tab == 3 ? null : FloatingActionButton.extended(
        onPressed: _addTask, icon: const Icon(Icons.add), label: const Text('تنبيه جديد'),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.checklist), label: 'مهامي'),
          NavigationDestination(icon: Icon(Icons.sports_esports), label: 'الألعاب'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'عن المطور'),
        ],
      ),
    );
  }

  Widget _dashboard() {
    final upcoming = tasks.take(4).toList();
    return ListView(padding: const EdgeInsets.all(18), children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(colors: [Color(0xFF254B88), Color(0xFF17243A)]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('وقتك مهم، لا تفوّت موعدك.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(_today(), style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 18),
          Text('${tasks.length} تنبيه محفوظ', style: const TextStyle(fontSize: 15)),
        ]),
      ),
      const SizedBox(height: 22),
      const Text('تنبيهاتك القادمة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      if (upcoming.isEmpty) const _EmptyState(text: 'ما عندك تنبيهات حالياً. أضف أول تنبيه لك!'),
      ...upcoming.map(_taskCard),
      const SizedBox(height: 20),
      Card(child: ListTile(
        leading: const Icon(Icons.favorite, color: Colors.pinkAccent),
        title: const Text('دعاء للوالدين'),
        subtitle: const Text('اللهم احفظ أمي وأبي وأطل في عمرهما على طاعتك'),
        onTap: () => setState(() => tab = 3),
      )),
    ]);
  }

  String _today() {
    final d = DateTime.now();
    return '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';
  }

  Widget _taskList(String title, List<LaloTask> items) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      if (items.isEmpty) const _EmptyState(text: 'لا توجد عناصر هنا بعد.'),
      ...items.map(_taskCard),
    ],
  );

  Widget _taskCard(LaloTask t) {
    final color = t.priority == 'مهمة جداً' ? Colors.redAccent :
      t.priority == 'شبه عادية' ? Colors.orangeAccent : Colors.greenAccent;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color.withOpacity(.15), child: Icon(
          t.kind == 'لعبة' ? Icons.sports_esports : Icons.event_note, color: color)),
        title: Text(t.title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${t.dateText} • ${t.timeText} • ${t.dateType}\n${t.priority}${t.note.isEmpty ? '' : ' • ${t.note}'}'),
        isThreeLine: true,
        trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _delete(t)),
      ),
    );
  }

  Widget _about() => ListView(padding: const EdgeInsets.all(20), children: [
    const SizedBox(height: 18),
    const CircleAvatar(radius: 42, backgroundColor: Color(0xFF254B88), child: Icon(Icons.code, size: 42)),
    const SizedBox(height: 14),
    const Center(child: Text('LALO', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 3))),
    const Center(child: Text('عن المطور', style: TextStyle(color: Colors.white70))),
    const SizedBox(height: 20),
    const Card(child: Padding(padding: EdgeInsets.all(18), child: Column(children: [
      Text('مهند', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      SizedBox(height: 8),
      Text('مطور فكرة وتطبيق LALO', textAlign: TextAlign.center),
      SizedBox(height: 8),
      Text('صُمم LALO ليجمع المهام والمواعيد وتنبيهات الألعاب في مكان واحد.', textAlign: TextAlign.center),
    ]))),
    const SizedBox(height: 16),
    const Text('دعاء لأمي وأبي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const Card(child: Padding(padding: EdgeInsets.all(18), child: Text(
      'اللهم احفظ أمي وأبي بعينك التي لا تنام، وألبسهما لباس الصحة والعافية، وأطل في عمرهما على طاعتك، وبارك لهما في أيامهما، وارزقهما راحة القلب وسعادة الدارين، واجزهما عني خير الجزاء.',
      textAlign: TextAlign.center, style: TextStyle(fontSize: 17, height: 1.8),
    ))),
  ]);
}

class AddTaskSheet extends StatefulWidget {
  const AddTaskSheet({super.key});
  @override
  State<AddTaskSheet> createState() => _AddTaskSheetState();
}

class _AddTaskSheetState extends State<AddTaskSheet> {
  final title = TextEditingController();
  final note = TextEditingController();
  String kind = 'مهمة', priority = 'عادية', dateType = 'ميلادي';
  DateTime? date;
  TimeOfDay? time;
  bool alarm = true;
  bool saving = false;

  @override
  void dispose() { title.dispose(); note.dispose(); super.dispose(); }

  Future<void> _pickDate() async {
    final d = await showDatePicker(context: context, initialDate: DateTime.now().add(const Duration(days: 1)),
      firstDate: DateTime(2020), lastDate: DateTime(2100));
    if (d != null) setState(() => date = d);
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (t != null) setState(() => time = t);
  }

  Future<void> _submit() async {
    if (title.text.trim().isEmpty || date == null || time == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل العنوان والتاريخ والوقت أولاً')));
      return;
    }
    setState(() => saving = true);
    int? nid;
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final scheduled = DateTime(date!.year, date!.month, date!.day, time!.hour, time!.minute);
    if (alarm && dateType == 'ميلادي' && scheduled.isAfter(DateTime.now())) {
      nid = scheduled.millisecondsSinceEpoch.remainder(2147483647);
      try {
        await notifications.zonedSchedule(
          nid,
          title.text.trim(),
          note.text.trim().isEmpty ? 'حان موعد تنبيهك في LALO' : note.text.trim(),
          tz.TZDateTime.from(scheduled, tz.local),
          const NotificationDetails(
            android: AndroidNotificationDetails('lalo_reminders', 'تنبيهات LALO',
              channelDescription: 'تنبيهات المهام والألعاب', importance: Importance.max,
              priority: Priority.high, playSound: true),
            iOS: DarwinNotificationDetails(presentAlert: true, presentSound: true),
          ),
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        );
      } catch (_) { nid = null; }
    }
    final result = LaloTask(
      id: id, title: title.text.trim(), kind: kind, priority: priority,
      dateText: dateType == 'ميلادي'
        ? '${date!.day}/${date!.month}/${date!.year}'
        : 'أدخل التاريخ الهجري: ${date!.day}/${date!.month}/${date!.year}',
      timeText: time!.format(context), dateType: dateType, note: note.text.trim(), notificationId: nid,
    );
    if (mounted) Navigator.pop(context, result);
  }

  @override
  Widget build(BuildContext context) {
    final dateLabel = date == null ? 'اختر التاريخ' :
      dateType == 'ميلادي' ? '${date!.day}/${date!.month}/${date!.year}' : 'تاريخ هجري مدخل كتاريخ: ${date!.day}/${date!.month}/${date!.year}';
    return Padding(
      padding: EdgeInsets.only(left: 18, right: 18, top: 20, bottom: MediaQuery.of(context).viewInsets.bottom + 24),
      child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('تنبيه جديد', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        TextField(controller: title, decoration: const InputDecoration(labelText: 'اسم المهمة أو الحدث')),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: kind, decoration: const InputDecoration(labelText: 'نوع التنبيه'),
          items: const [DropdownMenuItem(value: 'مهمة', child: Text('مهمة عادية')), DropdownMenuItem(value: 'لعبة', child: Text('حدث لعبة'))],
          onChanged: (v) => setState(() => kind = v!)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: priority, decoration: const InputDecoration(labelText: 'الأهمية'),
          items: const [DropdownMenuItem(value: 'عادية', child: Text('عادية')), DropdownMenuItem(value: 'شبه عادية', child: Text('شبه عادية')), DropdownMenuItem(value: 'مهمة جداً', child: Text('مهمة جداً'))],
          onChanged: (v) => setState(() => priority = v!)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: dateType, decoration: const InputDecoration(labelText: 'نوع التاريخ'),
          items: const [DropdownMenuItem(value: 'ميلادي', child: Text('ميلادي')), DropdownMenuItem(value: 'هجري', child: Text('هجري (إدخال يدوي في هذه النسخة)'))],
          onChanged: (v) => setState(() { dateType = v!; date = null; })),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: _pickDate, icon: const Icon(Icons.calendar_month), label: Text(dateLabel)),
        OutlinedButton.icon(onPressed: _pickTime, icon: const Icon(Icons.access_time), label: Text(time?.format(context) ?? 'اختر وقت المنبه')),
        const SizedBox(height: 8),
        TextField(controller: note, maxLines: 2, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
        SwitchListTile(value: alarm, onChanged: (v) => setState(() => alarm = v), title: const Text('تفعيل صوت التنبيه')),
        const SizedBox(height: 10),
        FilledButton(onPressed: saving ? null : _submit, child: Text(saving ? 'جارٍ الحفظ...' : 'حفظ التنبيه')),
      ])),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.text});
  final String text;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(padding: const EdgeInsets.all(24), child: Center(
      child: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
    )),
  );
}
